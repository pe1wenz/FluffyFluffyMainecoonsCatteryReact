package com.peiwen.fluffyfluffycattery.fluffyfluffycatterybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FluffyfluffycatterybackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FluffyfluffycatterybackendApplication.class, args);
	}

}
